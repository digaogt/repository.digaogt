script.module.hyper
=====================

Python HTTP2 library packed for KODI.

See more: https://github.com/Lukasa/hyper