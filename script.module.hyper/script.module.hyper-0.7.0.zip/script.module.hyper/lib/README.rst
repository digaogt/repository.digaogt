Hyper: HTTP/2 Client for Python
===============================

Release v0.7.0.

HTTP is changing under our feet. HTTP/1.1, our old friend, is being supplemented by the brand new HTTP/2 standard. HTTP/2 provides many benefits: improved speed, lower bandwidth usage, better connection management, and more.

hyper provides these benefits to your Python code. How? Like this:

from hyper import HTTPConnection

conn = HTTPConnection('http2bin.org:443')
conn.request('GET', '/get')
resp = conn.get_response()

print(resp.read())
Simple. hyper is written in 100% pure Python, which means no C extensions. For recent versions of Python (3.4 and onward, and 2.7.9 and onward) it’s entirely self-contained with no external dependencies.

hyper supports Python 3.4 and Python 2.7.9, and can speak HTTP/2 and HTTP/1.1.

Installing
----------

To begin, you will need to install hyper. This can be done like so:

$ pip install hyper
If pip is not available to you, you can try:

$ easy_install hyper
If that fails, download the library from its GitHub page and install it using:

$ python setup.py install

Documentation
-------------

hyper has usage and reference documentation at `hyper.readthedocs.io <https://hyper.readthedocs.io>`_.


Contributing
------------

hyper happily accepts contributions. Please see our
`contributing documentation <https://hyper.readthedocs.io/en/latest/contributing.html>`_
for some tips on getting started.

Maintainers
-----------

- `@lukasa <https://github.com/lukasa>`_ (Cory Benfield)

👋

Sponsorship
-----------

If your company benefits from this library, please consider `sponsoring its
development <https://hyper.readthedocs.io/en/latest/contributing.html#sponsorship>`_.
